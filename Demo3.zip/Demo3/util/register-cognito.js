// JS libraries used for Cognito
const amazonCogIdentity = require('amazon-cognito-identity-js');
// const aws = require('aws-sdk');
// const request = require('request');
// const jwkToPem = require('jwk-to-pem');
// const jsonWebToken = require('jsonwebtoken');

global.fetch = require('node-fetch');

const region = 'us-east-1';

const poolData = {
    UserPoolId: 'us-east-1_6B26YJx1m',
    ClientId: '7puof5ail3jgrcusbvlo6eg9f1',
};

// -- Sample Username/Email and Password --
const sampleData = {
    email: 'jbanzon@victor12.com',
    password: 'PassWord123!',
};

// ---------------------------------------

const userPool = new amazonCogIdentity.CognitoUserPool(poolData);

// Register User

var attributeList = [];

var userEmail = {
    Name: 'email',
    Value: sampleData.email, // insert user input here
};

var userName = {
    Name: 'name',
    Value: 'john banzon', // insert user input here
};

var userPhoneNumber = {
    Name: 'phone_number',
    Value: '+14074464386', // insert user input here
};

var attributeEmail = new amazonCogIdentity.CognitoUserAttribute(userEmail);
var attributeName = new amazonCogIdentity.CognitoUserAttribute(userName);
var attributePhoneNumber = new amazonCogIdentity.CognitoUserAttribute(userPhoneNumber);

attributeList.push(attributeEmail);
attributeList.push(attributeName);
attributeList.push(attributePhoneNumber);

userPool.signUp(sampleData.email, sampleData.password, attributeList, null, function(err, result) {
    if (err) {
        console.log(err);
        return;
    }

    var cognitoUser = result.user;

    console.log(result);
    console.log(cognitoUser);
});

// ---------------------------------------
