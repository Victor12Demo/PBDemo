const amazonCogIdentity = require('amazon-cognito-identity-js');
const windowmock = require('window-mock').default;

global.window = {localStorage: new windowmock().localStorage};

global.navigator = () => null;

global.fetch = require('node-fetch'); //  Required with using amazon-cognito-identity-js

// Dummy User Data
const userDummy = {
    Username: "jbanzon@victor12.com",
    Password: "PassWord123!",
};
// ------------------------------

// Cognito Userpool/Authentication Data
const poolData = {
    UserPoolId: 'us-east-1_6B26YJx1m',
    ClientId: '7puof5ail3jgrcusbvlo6eg9f1',
};

const userPool = new amazonCogIdentity.CognitoUserPool(poolData);

const userAuth = {
    Username: userDummy.Username,
    Pool: userPool,
};

var authDetails = new amazonCogIdentity.AuthenticationDetails(userDummy);
var cognitoUser = new amazonCogIdentity.CognitoUser(userAuth);
// ------------------------------


// Login Method

cognitoUser.authenticateUser(authDetails, {
    onSuccess: function (response) {
        console.log(response);
    },
    onFailure: function(err) {
        console.log(err);
    },
});

// ------------------------------
